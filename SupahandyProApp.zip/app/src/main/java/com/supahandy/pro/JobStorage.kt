package com.supahandy.pro

import android.content.Context
import android.content.SharedPreferences

class JobStorage(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("SupahandyJobs", Context.MODE_PRIVATE)

    fun saveJob(description: String, serviceType: String, laborRate: Double, hours: Double, materialCost: Double) {
        val jobId = System.currentTimeMillis().toString()
        val total = (laborRate * hours) + materialCost
        val jobData = "Description: $description\nService: $serviceType\nLabor: $$laborRate/hr x $hours\nMaterials: $$materialCost\nTotal: $$total"
        prefs.edit().putString(jobId, jobData).apply()
    }

    fun getAllJobs(): Map<String, String> {
        return prefs.all.mapValues { it.value.toString() }
    }
}