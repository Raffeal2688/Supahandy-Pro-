package com.supahandy.pro

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val laborRateInput = findViewById<EditText>(R.id.laborRateInput)
        val hoursInput = findViewById<EditText>(R.id.hoursInput)
        val materialCostInput = findViewById<EditText>(R.id.materialCostInput)
        val totalCostView = findViewById<TextView>(R.id.totalCostView)
        val calculateButton = findViewById<Button>(R.id.calculateButton)

        calculateButton.setOnClickListener {
            val laborRate = laborRateInput.text.toString().toDoubleOrNull() ?: 0.0
            val hours = hoursInput.text.toString().toDoubleOrNull() ?: 0.0
            val materialCost = materialCostInput.text.toString().toDoubleOrNull() ?: 0.0
            val totalCost = (laborRate * hours) + materialCost
            totalCostView.text = "Total Estimate: $${"%.2f".format(totalCost)}"
        }
    }
}